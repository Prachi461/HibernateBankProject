package Hibernate.Bank_Management_System;

import java.util.List;
import java.util.Scanner;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import Hibernate.Bank_Management_System.dao.CustomerDao;
import Hibernate.Bank_Management_System.dao.AccountDao;
import Hibernate.Bank_Management_System.dao.BranchDao;
import Hibernate.Bank_Management_System.dao.LoanDao;
import Hibernate.Bank_Management_System.dao.EmployeeDao;
import Hibernate.Bank_Management_System.daoIMPL.CustomerDaoIMPL;
import Hibernate.Bank_Management_System.daoIMPL.AccountDaoIMPL;
import Hibernate.Bank_Management_System.daoIMPL.BranchDaoIMPL;
import Hibernate.Bank_Management_System.daoIMPL.LoanDaoIMPL;
import Hibernate.Bank_Management_System.daoIMPL.EmployeeDaoIMPL;
import Hibernate.Bank_Management_System.entity.Account;
import Hibernate.Bank_Management_System.entity.Branch;
import Hibernate.Bank_Management_System.entity.Customer;
import Hibernate.Bank_Management_System.entity.Employee;
import Hibernate.Bank_Management_System.entity.Loan;
import Hibernate.Bank_Management_System.service.CustomerService;
import Hibernate.Bank_Management_System.service.AccountService;
import Hibernate.Bank_Management_System.service.BranchService;
import Hibernate.Bank_Management_System.service.LoanService;
import Hibernate.Bank_Management_System.service.EmployeeService;

public class App {
    private static final String ADMIN_USERNAME = "Prachi";
    private static final String ADMIN_PASSWORD = "Prachi123";

    public static void main(String[] args) {
        // SessionFactory
        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml") // Configuration file
                .addAnnotatedClass(Customer.class) // Annotated customer class
                .addAnnotatedClass(Account.class) // Annotated account class
                .addAnnotatedClass(Loan.class) // Annotated loan class
                .addAnnotatedClass(Employee.class) // Annotated employee class
                .addAnnotatedClass(Branch.class) // Annotated branch class
                .buildSessionFactory();

        //Creation of DAO objects
        CustomerDao customerDAO = new CustomerDaoIMPL(factory);
        AccountDao accountDAO = new AccountDaoIMPL(factory);
        BranchDao branchDAO = new BranchDaoIMPL(factory);
        LoanDao loanDAO = new LoanDaoIMPL(factory);
        EmployeeDao employeeDAO = new EmployeeDaoIMPL(factory);

        //Creation of Service objects
        CustomerService customerService = new CustomerService(customerDAO);
        AccountService accountService = new AccountService(accountDAO);
        BranchService branchService = new BranchService(branchDAO);
        LoanService loanService = new LoanService(loanDAO);
        EmployeeService employeeService = new EmployeeService(employeeDAO);

        //Scanner for taking log in input
        Scanner scanner = new Scanner(System.in);
        boolean isLoggedIn = false;
        int choice;

        //Admin login
        while (!isLoggedIn) {
            System.out.println("----------------Welcome to Bank Management System!--------------");
            System.out.println("--------------------------Admin Login---------------------------");
            System.out.print("Enter the username: ");
            String username = scanner.nextLine();
            System.out.print("Enter the password: ");
            String password = scanner.nextLine();

            // Login validation
            if (username.equals(ADMIN_USERNAME) && password.equals(ADMIN_PASSWORD)) {
                System.out.println("Login successfull!");
                isLoggedIn = true;
            } else {
                System.out.println("Invalid credentials... Please try again...");
                System.out.print("Do you want to try again? (yes/no): ");
                String retryChoice = scanner.nextLine();
                if (retryChoice.equalsIgnoreCase("no")) {
                    System.out.println("Exiting...");
                    factory.close(); // Close the session factory before exiting
                    scanner.close(); // Close scanner
                    return; // Exit the program
                }
            }
        }

        // If login successful, then menu is shown
        do {
            System.out.println("\nMain Menu:");
            System.out.println("1. Add Customer");
            System.out.println("2. Add Account");
            System.out.println("3. Add Employee");
            System.out.println("4. View all Customer Details");
            System.out.println("5. View all Accounts");
            System.out.println("6. View all Employee Details");
            System.out.println("7. View all Loans");
            System.out.println("8. View Branches");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume leftover newline

            switch (choice) {
                case 1:
                    //Add Customer
                    System.out.print("Enter id: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // Consume leftover newline
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter phone: ");
                    String phone = scanner.nextLine();

                    Customer customer = new Customer(id, name, email, phone);

                    try {
                        customerService.saveCustomer(customer); // Add the customer after validation
                        System.out.println("Customer added successfully!");
                    } catch (IllegalArgumentException e) {
                        System.out.println("Error: " + e.getMessage()); // Show validation error
                    }
                    break;
                    
                case 2:
                    //Add Accounts
                    System.out.print("Enter account id: ");
                    Long acc_id = scanner.nextLong();
                    scanner.nextLine(); // Consume leftover newline
                    System.out.print("Enter balance: ");
                    Double balance = scanner.nextDouble();
                 
                    Account account = new Account(acc_id, balance);

                    try {
                        accountService.saveAccount(account); //Adds the account details after validation
                        System.out.println("Account added successfully!");
                    } catch (IllegalArgumentException e) {
                        System.out.println("Error: " + e.getMessage()); //Show validation error
                    }
                    break;
                    
                case 3:
                    //Add Employee
                    System.out.print("Enter employee id: ");
                    int emp_id = scanner.nextInt();
                    scanner.nextLine(); // Consume leftover newline
                    System.out.print("Enter employee name: ");
                    String emp_name = scanner.nextLine();
                    System.out.print("Enter employee's post: ");
                    String post = scanner.nextLine();
                    System.out.print("Enter employee's salary: ");
                    Double salary = scanner.nextDouble();
                 
                    Employee employee = new Employee(emp_id, emp_name, post, salary);

                    try {
                        employeeService.save(employee); //Adds employee after validation
                        System.out.println("Employee added successfully!");
                    } catch (IllegalArgumentException e) {
                        System.out.println("Error: " + e.getMessage()); //Show validation error
                    }
                    break;

                case 4:
                    // View All Customers
                    List<Customer> customers = customerService.getAllCustomers();
                    if (customers.isEmpty()) {
                        System.out.println("No customers found!");
                    } else {
                        customers.forEach(System.out::println);
                    }
                    break;
                    
                case 5:
                    //Viewing all accounts
                    List<Account> accounts = accountService.getAllAccounts();
                    if (accounts.isEmpty()) {
                        System.out.println("No accounts found!");
                    } else {
                        accounts.forEach(System.out::println);
                    }
                    break;
                
                case 6:
                    //Viewing all employees
                    List<Employee> employees = employeeService.getAllEmployee();
                    if (employees.isEmpty()) {
                        System.out.println("No employees found!");
                    } else {
                        employees.forEach(System.out::println);
                    }
                    break;
                    
                case 7:
                    //Viewing all loans
                    List<Loan> loan = loanService.getAllLoan();
                    if (loan.isEmpty()) {
                        System.out.println("No loans found!");
                    } else {
                        loan.forEach(System.out::println);
                    }
                    break;
                    
                case 8:
                    //Viewing branches
                    List<Branch> branch = branchService.getAllBranches();
                    if (branch.isEmpty()) {
                        System.out.println("Some unexpected error occured!");
                    } else {
                        branch.forEach(System.out::println);
                    }
                    break;

                case 9:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice, please try again.");
            }
        } while (choice != 9);

        // Close resources
        scanner.close();
        factory.close();
    }
}