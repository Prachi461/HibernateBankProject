package Hibernate.Bank_Management_System.daoIMPL;

import javax.validation.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import Hibernate.Bank_Management_System.dao.BranchDao;
import Hibernate.Bank_Management_System.entity.Branch;
import Hibernate.Bank_Management_System.util.HibernateUtil;

import java.util.List;
import java.util.Set;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public class BranchDaoIMPL implements BranchDao {
	
    private SessionFactory sessionFactory;
    private BranchDao branchDao;
    //Validation
    private Validator validator;

    // Constructor to inject SessionFactory
    public BranchDaoIMPL(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
 
    }

    // To get all customers
    @Override
    public List<Branch> getAllBranches() {
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        Query<Branch> query = session.createQuery("from Branch", Branch.class); //To retrieve exisitng branch details
        List<Branch> branch = query.getResultList();

        transaction.commit();
        return branch;
    }
}
