package Hibernate.Bank_Management_System.daoIMPL;

import javax.validation.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import Hibernate.Bank_Management_System.dao.CustomerDao;
import Hibernate.Bank_Management_System.entity.Customer;
import Hibernate.Bank_Management_System.util.HibernateUtil;

import java.util.List;
import java.util.Set;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public class CustomerDaoIMPL implements CustomerDao {
	
    private SessionFactory sessionFactory;
    private CustomerDao customerDao;
    //Validation
    private Validator validator;

    // Constructor to inject SessionFactory
    public CustomerDaoIMPL(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        this.validator = factory.getValidator();
    }

    // For adding and saving customer
    @Override
    public void save(Customer customer) {
    	//To Validate customer
        Set<ConstraintViolation<Customer>> violations = validator.validate(customer);
        if (!violations.isEmpty()) {
            for (ConstraintViolation<Customer> violation : violations) {
                System.out.println(violation.getMessage());
            }
            return;
        }
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        session.save(customer); // Save customer to the database

        transaction.commit(); // Commit the transaction
        System.out.println("Customer added successfully!");
    }

    //To get customer by customer id
    @Override
    public Customer getById(int customer_id) {
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        Customer customer = session.get(Customer.class, customer_id); // Fetch customer by ID

        transaction.commit();
        return customer;
    }

    // To get all customers
    @Override
    public List<Customer> getAllCustomers() {
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        Query<Customer> query = session.createQuery("from Customer", Customer.class); // Retrieve all customers
        List<Customer> customers = query.getResultList();

        transaction.commit();
        return customers;
    }
}
