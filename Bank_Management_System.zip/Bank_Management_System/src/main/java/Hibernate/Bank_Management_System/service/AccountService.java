package Hibernate.Bank_Management_System.service;

import java.util.List;

import Hibernate.Bank_Management_System.dao.AccountDao;
import Hibernate.Bank_Management_System.entity.Account;


public class AccountService {
    private AccountDao accountDAO;

    // Constructor to inject DAO
    public AccountService(AccountDao accountDAO) {
        this.accountDAO = accountDAO;
    }

    // Add a new account
    public void saveAccount(Account account) {
        accountDAO.save(account);
    }

    // Get account by ID
    public Account getAccount(Long acc_id) {
        return accountDAO.findById(acc_id);
    }

    // Get all accounts
    public List<Account> getAllAccounts() {
        return accountDAO.getAllAccounts();
    }
}
