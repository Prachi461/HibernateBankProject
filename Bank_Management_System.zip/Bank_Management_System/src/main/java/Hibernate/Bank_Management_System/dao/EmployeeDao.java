package Hibernate.Bank_Management_System.dao;

import java.util.List;

import Hibernate.Bank_Management_System.entity.Employee;


public interface EmployeeDao{    
    //To add employee
	void save(Employee employee);
    
	//To fetch employee by employee id
	Employee getById(int emp_id);
	
	//To get all Customer details
    List<Employee> getAllEmployee();
    
}